<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

$arDescription = Array(
		"NAME"=>GetMessage("GD_USERS_ONLINE"),
		"DESCRIPTION"=>GetMessage("GD_USERS_ONLINE_DESC"),
		"ICON"=>"gadget.png",
		"GROUP"=> Array("ID"=>"employees"),
		"CAN_BE_FIXED"=> true,
	);
?>
