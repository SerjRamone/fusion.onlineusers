<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
   "NAME" => GetMessage("COMP_NAME"),
   "DESCRIPTION" => GetMessage("COMP_DESCR"),
   "ICON" => "/images/count_users.gif",
   "SORT" => 30,
   "PATH" => array(
		"ID" => "utility",
   ),
   "CACHE_PATH" => "N"
);
?>