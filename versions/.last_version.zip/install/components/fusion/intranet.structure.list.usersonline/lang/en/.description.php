<?
$MESS ['INTR_GROUP_NAME'] = "Intranet Portal";
$MESS ['INTR_ISL_COMPONENT_NAME'] = "Employees online";
$MESS ['INTR_ISL_COMPONENT_DESCR'] = "Displays online employees";
$MESS ['INTR_STRUCTURE_GROUP_NAME'] = "Company Structure";
?>