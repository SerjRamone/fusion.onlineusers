<?
$MESS ['INTR_ISL_PARAM_DETAIL_URL'] = "Detail View Page";
$MESS ['INTR_ISL_PARAM_SHOW_ERROR_ON_NULL'] = "Display Warning on Empty Result";
$MESS ['INTR_ISL_PARAM_USERS_PER_PAGE'] = "Users Per Page";
$MESS ['INTR_ISL_PARAM_NAV_TITLE'] = "Breadcrumbs Title";
$MESS ['INTR_ISL_PARAM_NAV_TITLE_DEFAULT'] = "Employees";
$MESS ['INTR_ISL_PARAM_SHOW_NAV_TOP'] = "Show Breadcrumbs Above Results";
$MESS ['INTR_ISL_PARAM_SHOW_NAV_BOTTOM'] = "Show Breadcrumbs Below Results";
$MESS ['INTR_ISL_PARAM_NAME_TEMPLATE'] = "Name Format";
?>