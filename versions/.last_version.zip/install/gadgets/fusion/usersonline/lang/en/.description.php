<?
$MESS ['GD_USERS_ONLINE'] = "Users online";
$MESS ['GD_USERS_ONLINE_DESC'] = "Shows online employees";
?>