<?
$MESS ['GD_USERS_ONLINE_LIST_URL'] = "Online users page URL";
?>