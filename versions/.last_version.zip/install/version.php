<?
$arModuleVersion = array(
	"VERSION" => "1.0.0",
	"VERSION_DATE" => "2013-01-14 09:00:00"
);
?>